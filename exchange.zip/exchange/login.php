<?php
header("Content-Type: application/json");

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "exchange";


$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Database connection failed: " . $conn->connect_error]);
    exit();
}


if (!isset($_GET['mail_id']) || !isset($_GET['password'])) {
    http_response_code(400);
    echo json_encode(["error" => "Missing parameters"]);
    exit();
}


$mail_id = $_GET['mail_id'];
$password = $_GET['password'];


$sql = "SELECT * FROM login WHERE mail_id = ? AND password = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $mail_id, $password);

if ($stmt->execute()) {
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        http_response_code(200);
        echo json_encode(["message" => "Welcome to Exchange Electronics & Vehicles app"]);
    } else {
        http_response_code(401);
        echo json_encode(["message" => "Given user ID and password is incorrect"]);
    }
} else {
    http_response_code(500);
    echo json_encode(["error" => "Internal server error"]);
}

$stmt->close();
$conn->close();
?>
