<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


$servername = "localhost";
$username = "root"; 
$password = "";      
$dbname = "exchange"; 

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die(json_encode(["status" => "error", "message" => "Database connection failed: " . $conn->connect_error]));
}


$rawData = !empty(file_get_contents("php://input")) 
           ? file_get_contents("php://input") 
           : json_encode($_POST); 


file_put_contents("debug_log.txt", "Raw Data: " . $rawData . PHP_EOL, FILE_APPEND);

$data = json_decode($rawData, true);


if ($data === null) {
    echo json_encode([
        "status" => "error",
        "message" => "Invalid JSON format",
        "debug" => ["rawData" => $rawData, "json_error" => json_last_error_msg()]
    ]);
    exit;
}


$action = trim(strtolower($data['action'] ?? ''));
$sender_email = trim($data['sender_email'] ?? '');
$receiver_email = trim($data['receiver_email'] ?? '');
$message = trim($data['message'] ?? '');


file_put_contents("debug_log.txt", "Parsed Data: " . print_r($data, true) . PHP_EOL, FILE_APPEND);


if (empty($sender_email) || empty($receiver_email)) {
    echo json_encode([
        "status" => "error",
        "message" => "Missing sender or receiver email.",
        "debug" => ["sender_email" => $sender_email, "receiver_email" => $receiver_email]
    ]);
    exit;
}


function getChatID($conn, $sender, $receiver) {
    $stmt = $conn->prepare("SELECT id FROM request WHERE 
        (requested_mail_id = ? AND seller_mail_id = ?) 
        OR (requested_mail_id = ? AND seller_mail_id = ?)");
    $stmt->bind_param("ssss", $sender, $receiver, $receiver, $sender);
    $stmt->execute();
    $chat_result = $stmt->get_result();

    if ($chat_result->num_rows > 0) {
        $chat_row = $chat_result->fetch_assoc();
        return $chat_row['id']; 
    } else {
        return null;
    }
}


if ($action === 'send') {   
    
    $chat_id = getChatID($conn, $sender_email, $receiver_email);

    if ($chat_id !== null) {
        
        $stmt = $conn->prepare("INSERT INTO messages (chat_id, sender_email, receiver_email, message) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("isss", $chat_id, $sender_email, $receiver_email, $message);

        if ($stmt->execute()) {
            echo json_encode(["status" => "success", "message" => "Message sent"]);
        } else {
            echo json_encode(["status" => "error", "message" => "Error sending message", "error" => $stmt->error]);
        }
    } else {
        echo json_encode(["status" => "error", "message" => "No valid request found between the users."]);
    }
} elseif ($action === 'load') {
    
    $chat_id = getChatID($conn, $sender_email, $receiver_email);

    if ($chat_id !== null) {
        
        $stmt = $conn->prepare("SELECT sender_email, receiver_email, message, timestamp FROM messages WHERE chat_id = ? ORDER BY timestamp ASC");
        $stmt->bind_param("i", $chat_id);
        $stmt->execute();
        $result = $stmt->get_result();

        $messages = [];
        while ($row = $result->fetch_assoc()) {
            $messages[] = $row;
        }

        echo json_encode(["status" => "success", "chat_id" => $chat_id, "messages" => $messages]);
    } else {
        echo json_encode(["status" => "error", "message" => "No chat found between these users"]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "Invalid action"]);
}

$conn->close();
?>
