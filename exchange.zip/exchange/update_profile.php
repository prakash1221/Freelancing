<?php
header("Content-Type: application/json");

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "exchange";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    echo json_encode(["error" => "Database connection failed: " . $conn->connect_error]);
    exit();
}

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    echo json_encode(["error" => "Only POST method is allowed"]);
    exit();
}

if (!isset($_POST["mail_id"]) || !isset($_POST["name"]) || !isset($_POST["phone_number"])) {
    echo json_encode(["error" => "All required fields must be provided"]);
    exit();
}

$mail_id = trim($_POST["mail_id"]);
$name = trim($_POST["name"]);
$phone_number = trim($_POST["phone_number"]);
$location = isset($_POST["location"]) ? trim($_POST["location"]) : null;

$query = "UPDATE sign_up SET name = ?, phone_number = ?, location = ? WHERE mail_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("ssss", $name, $phone_number, $location, $mail_id);

if ($stmt->execute()) {
    echo json_encode(["message" => "Profile updated successfully"]);
} else {
    echo json_encode(["error" => "Failed to update profile"]);
}

$stmt->close();
$conn->close();
?>
