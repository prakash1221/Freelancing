<?php
header("Content-Type: application/json");

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "exchange";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Database connection failed: " . $conn->connect_error]);
    exit();
}

if ($_SERVER["REQUEST_METHOD"] != "POST") {
    http_response_code(405);
    echo json_encode(["error" => "Only POST method is allowed"]);
    exit();
}

if (!isset($_FILES["image"]) || !isset($_POST["item_name"]) || !isset($_POST["category"]) || 
    !isset($_POST["price"]) || !isset($_POST["imei_number"]) || !isset($_POST["description"]) || 
    !isset($_POST["mail_id"])) {
    http_response_code(400);
    echo json_encode(["error" => "All fields are required"]);
    exit();
}

$mail_id = trim($_POST["mail_id"]);
$item_name = trim($_POST["item_name"]);
$category = trim($_POST["category"]);
$price = trim($_POST["price"]);
$imei_number = trim($_POST["imei_number"]);
$description = trim($_POST["description"]);

$check_mail_query = "SELECT mail_id FROM sign_up WHERE mail_id = ?";
$check_stmt = $conn->prepare($check_mail_query);
$check_stmt->bind_param("s", $mail_id);
$check_stmt->execute();
$result = $check_stmt->get_result();

if ($result->num_rows == 0) {
    http_response_code(400);
    echo json_encode(["error" => "This mail ID is not registered in sign_up table"]);
    exit();
}
$check_stmt->close();

if (!in_array($category, ["electronics", "vehicles"])) {
    http_response_code(400);
    echo json_encode(["error" => "Invalid category. Choose 'electronics' or 'vehicles'"]);
    exit();
}

if (!ctype_digit($price) || (int)$price <= 0) {
    http_response_code(400);
    echo json_encode(["error" => "Invalid price. Only positive numbers are allowed"]);
    exit();
}

if (!preg_match("/^[a-zA-Z0-9]+$/", $imei_number)) {
    http_response_code(400);
    echo json_encode(["error" => "Invalid IMEI number. Only letters and numbers are allowed"]);
    exit();
}

if (str_word_count($description) > 300) {
    http_response_code(400);
    echo json_encode(["error" => "Description must be 300 words or less"]);
    exit();
}

$target_dir = "uploads/";
if (!file_exists($target_dir)) {
    mkdir($target_dir, 0777, true);
}
$image_name = basename($_FILES["image"]["name"]);
$image_path = $target_dir . time() . "_" . $image_name;
$image_file_type = strtolower(pathinfo($image_path, PATHINFO_EXTENSION));

$allowed_types = ["jpg", "jpeg", "png"];
if (!in_array($image_file_type, $allowed_types)) {
    http_response_code(400);
    echo json_encode(["error" => "Invalid image format. Only JPG, JPEG, and PNG allowed"]);
    exit();
}

if (!move_uploaded_file($_FILES["image"]["tmp_name"], $image_path)) {
    http_response_code(500);
    echo json_encode(["error" => "Failed to upload image"]);
    exit();
}

$unique_id_prefix = ($category === "electronics") ? "EL" : "VE";
$unique_id = $unique_id_prefix . rand(100, 999);

$sql = "INSERT INTO exchange_items_list (mail_id, image, item_name, category, price, imei_number, description, unique_id) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssssisss", $mail_id, $image_path, $item_name, $category, $price, $imei_number, $description, $unique_id);

if ($stmt->execute()) {
    http_response_code(201);
    echo json_encode(["message" => "Item uploaded successfully", "unique_id" => $unique_id]);
} else {
    http_response_code(500);
    echo json_encode(["error" => "Failed to save data in database"]);
}

$stmt->close();
$conn->close();
?>
