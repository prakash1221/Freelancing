<?php
header("Content-Type: application/json");

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "exchange";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    echo json_encode(["error" => "Database connection failed: " . $conn->connect_error]);
    exit();
}

$mail_id = "hemaprakash@gmail.com";
$query = "SELECT name, mail_id, phone_number, location FROM sign_up WHERE mail_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $mail_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $profile = $result->fetch_assoc();
    $profile["location_url"] = !empty($profile["location"]) ? "https://www.google.com/maps?q=" . urlencode($profile["location"]) : null;
    
    echo json_encode($profile, JSON_PRETTY_PRINT);
} else {
    echo json_encode(["error" => "User not found"]);
}

$stmt->close();
$conn->close();
?>
