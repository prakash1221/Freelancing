<?php
header("Content-Type: application/json");

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "exchange";


$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Database connection failed: " . $conn->connect_error]);
    exit();
}


if ($_SERVER["REQUEST_METHOD"] != "GET") {
    http_response_code(405);
    echo json_encode(["error" => "Only GET method is allowed"]);
    exit();
}


if (!isset($_GET["seller_mail_id"])) {
    http_response_code(400);
    echo json_encode(["error" => "Seller Mail ID is required"]);
    exit();
}


$seller_mail_id = trim($_GET["seller_mail_id"]);


$request_query = "SELECT requested_mail_id, unique_id, messages, my_item FROM request WHERE seller_mail_id = ?";
$request_stmt = $conn->prepare($request_query);
$request_stmt->bind_param("s", $seller_mail_id);
$request_stmt->execute();
$request_result = $request_stmt->get_result();

if ($request_result->num_rows == 0) {
    http_response_code(404);
    echo json_encode(["error" => "No requests found for this seller"]);
    exit();
}

$requests = [];
while ($request = $request_result->fetch_assoc()) {
    $requested_mail_id = $request["requested_mail_id"];
    $imei_number = $request["my_item"];
    
    
    $item_query = "SELECT image, item_name, category, price, description, unique_id FROM exchange_items_list WHERE imei_number = ? AND mail_id = ?";
    $item_stmt = $conn->prepare($item_query);
    $item_stmt->bind_param("ss", $imei_number, $requested_mail_id);
    $item_stmt->execute();
    $item_result = $item_stmt->get_result();
    
    if ($item_result->num_rows > 0) {
        $item_details = $item_result->fetch_assoc();
        
        $requests[] = [
            "requested_mail_id" => $requested_mail_id,
            "message" => $request["messages"],
            "requested_item" => [
                "image" => $item_details["image"],
                "item_name" => $item_details["item_name"],
                "category" => $item_details["category"],
                "price" => $item_details["price"],
                "description" => $item_details["description"],
                "unique_id" => $item_details["unique_id"]
            ]
        ];
    }
    $item_stmt->close();
}


http_response_code(200);
echo json_encode(["requests" => $requests]);


$request_stmt->close();
$conn->close();
?>
