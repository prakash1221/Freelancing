<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

header("Content-Type: application/json");

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "exchange";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    echo json_encode([
        "status" => "error",
        "message" => "Database connection failed: " . $conn->connect_error
    ]);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $first_name = isset($_POST['first_name']) ? $_POST['first_name'] : '';
    $last_name = isset($_POST['last_name']) ? $_POST['last_name'] : '';
    $mail_id = isset($_POST['mail_id']) ? $_POST['mail_id'] : '';
    $phone_number = isset($_POST['phone_number']) ? $_POST['phone_number'] : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';
    $confirm_password = isset($_POST['confirm_password']) ? $_POST['confirm_password'] : '';

    if (empty($first_name) || empty($last_name) || empty($mail_id) || empty($phone_number) || empty($password) || empty($confirm_password)) {
        echo json_encode([
            "status" => "error",
            "message" => "Enter every information"
        ]);
        exit();
    }

    if ($password !== $confirm_password) {
        echo json_encode([
            "status" => "error",
            "message" => "Enter the proper password"
        ]);
        exit();
    }

    $phone_check_query = "SELECT phone_number FROM sign_up WHERE phone_number = ?";
    $stmt = $conn->prepare($phone_check_query);
    if (!$stmt) {
        echo json_encode([
            "status" => "error",
            "message" => "Failed to prepare phone check query: " . $conn->error
        ]);
        exit();
    }
    $stmt->bind_param("s", $phone_number);
    $stmt->execute();
    $stmt->store_result();
    if ($stmt->num_rows > 0) {
        echo json_encode([
            "status" => "error",
            "message" => "The given mobile number already exists. Please enter a proper mobile number."
        ]);
        $stmt->close();
        $conn->close();
        exit();
    }
    $stmt->close();

    $email_check_query = "SELECT mail_id FROM sign_up WHERE mail_id = ? UNION SELECT mail_id FROM login WHERE mail_id = ?";
    $stmt = $conn->prepare($email_check_query);
    if (!$stmt) {
        echo json_encode([
            "status" => "error",
            "message" => "Failed to prepare email check query: " . $conn->error
        ]);
        exit();
    }
    $stmt->bind_param("ss", $mail_id, $mail_id);
    $stmt->execute();
    $stmt->store_result();
    if ($stmt->num_rows > 0) {
        echo json_encode([
            "status" => "error",
            "message" => "The given mail ID already exists. Please try with a unique mail ID."
        ]);
        $stmt->close();
        $conn->close();
        exit();
    }
    $stmt->close();

    $name = $first_name . ' ' . $last_name;

    $insert_sign_up_query = "INSERT INTO sign_up (name, mail_id, phone_number, password) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($insert_sign_up_query);
    if (!$stmt) {
        echo json_encode([
            "status" => "error",
            "message" => "Failed to prepare sign-up insert query: " . $conn->error
        ]);
        exit();
    }
    $stmt->bind_param("ssss", $name, $mail_id, $phone_number, $password);
    if ($stmt->execute()) {
        $insert_login_query = "INSERT INTO login (mail_id, password) VALUES (?, ?)";
        $stmt = $conn->prepare($insert_login_query);
        if (!$stmt) {
            echo json_encode([
                "status" => "error",
                "message" => "Failed to prepare login insert query: " . $conn->error
            ]);
            exit();
        }
        $stmt->bind_param("ss", $mail_id, $password);
        if ($stmt->execute()) {
            echo json_encode([
                "status" => "success",
                "message" => "Sign-up successful!"
            ]);
        } else {
            echo json_encode([
                "status" => "error",
                "message" => "Failed to insert into login table. MySQL error: " . $stmt->error
            ]);
        }
    } else {
        echo json_encode([
            "status" => "error",
            "message" => "Failed to insert into sign-up table. MySQL error: " . $stmt->error
        ]);
    }

    $stmt->close();
}

$conn->close();
?>
