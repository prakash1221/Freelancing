<?php
header("Content-Type: application/json");

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "exchange";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => "Database connection failed: " . $conn->connect_error]);
    exit();
}

$sql = "SELECT * FROM exchange_items_list";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $items = [];

    while ($row = $result->fetch_assoc()) {
        $items[] = [
            "id" => $row["id"],
            "mail_id" => $row["mail_id"],
            "image" => $row["image"],
            "item_name" => $row["item_name"],
            "category" => $row["category"],
            "price" => $row["price"],
            "imei_number" => $row["imei_number"],
            "description" => $row["description"],
            //"created_at" => $row["created_at"]
        ];
    }

    http_response_code(200);
    echo json_encode(["status" => "success", "items" => $items], JSON_PRETTY_PRINT);
} else {
    http_response_code(404);
    echo json_encode(["status" => "error", "message" => "No items found"]);
}

$conn->close();
?>
