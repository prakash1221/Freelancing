<?php
header("Content-Type: application/json");

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "exchange";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Database connection failed: " . $conn->connect_error]);
    exit();
}

if ($_SERVER["REQUEST_METHOD"] != "POST") {
    http_response_code(405);
    echo json_encode(["error" => "Only POST method is allowed"]);
    exit();
}

if (!isset($_POST["mail_id"]) || !isset($_POST["unique_id"]) || !isset($_POST["message"]) || !isset($_POST["imei_number"])) {
    http_response_code(400);
    echo json_encode(["error" => "All fields are required"]);
    exit();
}

$mail_id = trim($_POST["mail_id"]);
$unique_id = trim($_POST["unique_id"]);
$message = trim($_POST["message"]);
$imei_number = trim($_POST["imei_number"]);

$item_check_query = "SELECT mail_id FROM exchange_items_list WHERE unique_id = ?";
$item_stmt = $conn->prepare($item_check_query);
$item_stmt->bind_param("s", $unique_id);
$item_stmt->execute();
$item_result = $item_stmt->get_result();

if ($item_result->num_rows == 0) {
    http_response_code(400);
    echo json_encode(["error" => "Item not found"]);
    exit();
}

$item_data = $item_result->fetch_assoc();
$seller_mail_id = $item_data['mail_id'];

$check_my_item_query = "SELECT imei_number FROM exchange_items_list WHERE mail_id = ? AND imei_number = ?";
$my_item_stmt = $conn->prepare($check_my_item_query);
$my_item_stmt->bind_param("ss", $mail_id, $imei_number);
$my_item_stmt->execute();
$my_item_result = $my_item_stmt->get_result();

if ($my_item_result->num_rows == 0) {
    http_response_code(400);
    echo json_encode(["error" => "The provided IMEI number does not belong to the requester"]);
    exit();
}

if ($mail_id === $seller_mail_id) {
    http_response_code(400);
    echo json_encode(["error" => "You cannot request your own item."]);
    exit();
}

$request_check_query = "SELECT id FROM request WHERE requested_mail_id = ? AND unique_id = ?";
$request_check_stmt = $conn->prepare($request_check_query);
$request_check_stmt->bind_param("ss", $mail_id, $unique_id);
$request_check_stmt->execute();
$request_check_result = $request_check_stmt->get_result();

if ($request_check_result->num_rows > 0) {
    http_response_code(400);
    echo json_encode(["error" => "You have already sent a request for this product"]);
    exit();
}


$request_sql = "INSERT INTO request (requested_mail_id, seller_mail_id, unique_id, messages, my_item) VALUES (?, ?, ?, ?, ?)";
$request_stmt = $conn->prepare($request_sql);
$request_stmt->bind_param("sssss", $mail_id, $seller_mail_id, $unique_id, $message, $imei_number);

if ($request_stmt->execute()) {
    http_response_code(201);
    echo json_encode(["message" => "Request sent successfully"]);
} else {
    http_response_code(500);
    echo json_encode(["error" => "Failed to send request"]);
}

$request_stmt->close();
$item_stmt->close();
$my_item_stmt->close();
$request_check_stmt->close();
$conn->close();
?>
