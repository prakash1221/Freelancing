<?php
header("Content-Type: application/json");

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "exchange";

$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Database connection failed: " . $conn->connect_error]);
    exit();
}


if ($_SERVER["REQUEST_METHOD"] != "POST") {
    http_response_code(405);
    echo json_encode(["error" => "Only POST method is allowed"]);
    exit();
}


if (!isset($_POST["action"]) || !isset($_POST["seller_mail_id"]) || !isset($_POST["requested_mail_id"]) || !isset($_POST["unique_id"])) {
    http_response_code(400);
    echo json_encode(["error" => "All required fields must be provided"]);
    exit();
}


$action = trim($_POST["action"]);
$seller_mail_id = trim($_POST["seller_mail_id"]);
$requested_mail_id = trim($_POST["requested_mail_id"]);
$unique_id = trim($_POST["unique_id"]);
$note = isset($_POST["note"]) ? trim($_POST["note"]) : null;
$rating = isset($_POST["rating"]) ? intval($_POST["rating"]) : null;


if ($note !== null && strlen($note) > 250) {
    http_response_code(400);
    echo json_encode(["error" => "Note must be up to 250 characters"]);
    exit();
}


$check_request_query = "SELECT id FROM request WHERE seller_mail_id = ? AND requested_mail_id = ? AND unique_id = ?";
$check_request_stmt = $conn->prepare($check_request_query);
$check_request_stmt->bind_param("sss", $seller_mail_id, $requested_mail_id, $unique_id);
$check_request_stmt->execute();
$check_request_result = $check_request_stmt->get_result();

if ($check_request_result->num_rows == 0) {
    http_response_code(400);
    echo json_encode(["error" => "Invalid request: No matching request found"]);
    exit();
}


$check_existing_query = "
    SELECT 'accepted' AS status FROM accepted_requests WHERE seller_mail_id = ? AND requested_mail_id = ? AND unique_id = ?
    UNION
    SELECT 'rejected' AS status FROM rejected_requests WHERE seller_mail_id = ? AND requested_mail_id = ? AND unique_id = ?
    UNION
    SELECT 'complained' AS status FROM complaints WHERE seller_mail_id = ? AND requested_mail_id = ? AND unique_id = ?
";
$check_existing_stmt = $conn->prepare($check_existing_query);
$check_existing_stmt->bind_param("sssssssss", $seller_mail_id, $requested_mail_id, $unique_id, $seller_mail_id, $requested_mail_id, $unique_id, $seller_mail_id, $requested_mail_id, $unique_id);
$check_existing_stmt->execute();
$check_existing_result = $check_existing_stmt->get_result();

if ($check_existing_result->num_rows > 0) {
    $existing_action = $check_existing_result->fetch_assoc()["status"];
    http_response_code(400);
    echo json_encode(["error" => "Request already $existing_action. Cannot change it."]);
    exit();
}


if ($action === "accept") {
    
    if ($rating === null || $rating < 1 || $rating > 5) {
        http_response_code(400);
        echo json_encode(["error" => "Invalid rating. Must be between 1 and 5"]);
        exit();
    }

    $query = "INSERT INTO accepted_requests (seller_mail_id, requested_mail_id, unique_id, rating, note) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("sssis", $seller_mail_id, $requested_mail_id, $unique_id, $rating, $note);
    
    if ($stmt->execute()) {
        http_response_code(201);
        echo json_encode(["message" => "Request accepted successfully"]);
    } else {
        http_response_code(500);
        echo json_encode(["error" => "Failed to accept request"]);
    }

} elseif ($action === "reject") {
    
    $query = "INSERT INTO rejected_requests (seller_mail_id, requested_mail_id, unique_id, note) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ssss", $seller_mail_id, $requested_mail_id, $unique_id, $note);
    
    if ($stmt->execute()) {
        http_response_code(201);
        echo json_encode(["message" => "Request rejected successfully"]);
    } else {
        http_response_code(500);
        echo json_encode(["error" => "Failed to reject request"]);
    }

} elseif ($action === "complaint") {
    
    $query = "INSERT INTO complaints (seller_mail_id, requested_mail_id, unique_id, note) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ssss", $seller_mail_id, $requested_mail_id, $unique_id, $note);
    
    if ($stmt->execute()) {
        http_response_code(201);
        echo json_encode(["message" => "Complaint submitted successfully"]);
    } else {
        http_response_code(500);
        echo json_encode(["error" => "Failed to submit complaint"]);
    }

} else {
    http_response_code(400);
    echo json_encode(["error" => "Invalid action. Use 'accept', 'reject', or 'complaint'"]);
}

// Close connections
$stmt->close();
$check_request_stmt->close();
$check_existing_stmt->close();
$conn->close();
?>
